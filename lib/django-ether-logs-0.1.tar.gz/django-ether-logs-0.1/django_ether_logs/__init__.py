default_app_config = 'django_ether_logs.apps.EtherLogsConfig'
